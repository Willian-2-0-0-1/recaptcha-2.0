// index.js
require('dotenv').config();
const axios = require('axios');
const express = require('express');
const cors = require('cors'); // Importa o pacote cors
const { URL } = require('url');

const app = express();

// Habilita o CORS para todas as rotas
app.use(cors());
app.use(express.json());

/**
 * Função para obter a configuração do proxy a partir das variáveis de ambiente.
 * Prioriza o uso de 'http_proxy' se disponível, caso contrário, usa as variáveis individuais.
 */
function getProxyConfig() {
  if (process.env.http_proxy) {
    try {
      const parsedUrl = new URL(process.env.http_proxy);
      const proxyConfig = {
        host: parsedUrl.hostname,
        port: parsedUrl.port ? Number(parsedUrl.port) : undefined
      };
      if (parsedUrl.username || parsedUrl.password) {
        proxyConfig.auth = {
          username: parsedUrl.username,
          password: parsedUrl.password
        };
      }
      return proxyConfig;
    } catch (err) {
      console.error("Erro ao analisar a variável http_proxy:", err.message);
    }
  }

  if (process.env.PROXY_HOST && process.env.PROXY_PORT) {
    const proxyConfig = {
      host: process.env.PROXY_HOST,
      port: Number(process.env.PROXY_PORT)
    };
    if (process.env.PROXY_USERNAME && process.env.PROXY_PASSWORD) {
      proxyConfig.auth = {
        username: process.env.PROXY_USERNAME,
        password: process.env.PROXY_PASSWORD
      };
    }
    return proxyConfig;
  }

  return null;
}

/**
 * Função que valida o token enviado, integrando com o reCAPTCHA Enterprise.
 * Retorna true se o token for considerado válido (score >= 0.7) ou false caso contrário.
 */
async function validateRecaptchaToken(token) {
  const apiKey = process.env.RECAPTCHA_API_KEY;
  const siteKey = process.env.SITE_KEY;
  const expectedAction = process.env.EXPECTED_ACTION;

  if (!apiKey || !siteKey || !expectedAction) {
    throw new Error("As variáveis RECAPTCHA_API_KEY, SITE_KEY e EXPECTED_ACTION são obrigatórias.");
  }

  const url = `https://recaptchaenterprise.googleapis.com/v1/projects/bold-bucksaw-356216/assessments?key=${apiKey}`;

  const requestBody = {
    event: {
      token: token,
      siteKey: siteKey,
      expectedAction: expectedAction
    }
  };

  const proxyConfig = getProxyConfig();
  const axiosConfig = {};
  if (proxyConfig) {
    axiosConfig.proxy = proxyConfig;
    console.log("Utilizando configuração de proxy:", proxyConfig);
  } else {
    console.log("Nenhuma configuração de proxy encontrada. Conexão direta.");
  }

  let response;
  try {
    response = await axios.post(url, requestBody, axiosConfig);
  } catch (error) {
    if (error.code === "ENOTFOUND" && axiosConfig.proxy) {
      console.warn("Falha ao resolver o proxy. Tentando sem configuração de proxy...");
      try {
        response = await axios.post(url, requestBody, { proxy: false });
      } catch (err2) {
        console.error("Tentativa sem proxy também falhou:", err2.message);
        return false;
      }
    } else {
      console.error("Erro ao validar o token reCAPTCHA:", error.message);
      return false;
    }
  }

  if (response.data && response.data.riskAnalysis) {
    const score = response.data.riskAnalysis.score;
    console.log(`Score retornado: ${score}`);
    if (score >= 0.7) {
      return true;
    } else {
      console.error(`Validação reCAPTCHA falhou. Score de risco: ${score}`);
      return false;
    }
  } else {
    console.error("Resposta inválida da API do reCAPTCHA.");
    return false;
  }
}

/**
 * Endpoint para receber e validar o token do reCAPTCHA.
 */
app.post('/validate-token', async (req, res) => {
  const token = req.body.token;
  if (!token) {
    return res.status(400).json({ success: false, message: 'Token não informado' });
  }

  try {
    const isValid = await validateRecaptchaToken(token);
    if (isValid) {
      res.json({ success: true, message: 'Token validado com sucesso' });
    } else {
      res.status(400).json({ success: false, message: 'Falha na validação do token' });
    }
  } catch (error) {
    console.error("Erro interno:", error.message);
    res.status(500).json({ success: false, message: 'Erro interno no servidor' });
  }
});

// Inicialização do servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor ouvindo na porta ${PORT}`);
});
